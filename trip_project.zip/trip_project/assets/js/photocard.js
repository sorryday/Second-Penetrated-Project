function selectPhoto(id) {
  localStorage.setItem("contentId", id);
  window.location.replace("map.html");
}

function setPhoto() {
  const photoCard = document.getElementById("photo_card");

  const trips = JSON.parse(localStorage.getItem("trips"));

  let answer = ``;

  for (let i = 0; i < trips.length; i++) {
    if (trips[i].firstimage === "") continue;
    answer += `
            <div class="card">
                <img class="card_img" src=${trips[i].firstimage} alt="" />
                <div class="portcard_link">
                    <i class="bx bx-link" onclick="selectPhoto(${trips[i].contentid})"></i>
                </div>
            </div>
        `;
  }

  photoCard.innerHTML += answer;

  const initlist = [
    {
      title: "Log In",
      href: "login.html",
    },
    {
      title: "My Page",
      href: "mypage.html",
    },
    {
      title: "Log Out",
      href: "logout.html",
    },
    {
      title: "Board",
      href: "board.html",
    },
  ];

  let navContents = document.getElementById("nav_list");
  let navAnswer = ``;

  for (let i = 0; i < 4; i++) {
    if (i === 3) {
      navAnswer += `
                    <li>
                        <a class="nav-link scrollto" href=${initlist[i].href}>
                            ${initlist[i].title}
                        </a>
                    </li>
                `;
    }

    if (!localStorage.getItem("loginUser")) {
      if (i === 0) {
        navAnswer += `
                    <li>
                        <a class="nav-link scrollto" href=${initlist[i].href}>
                            ${initlist[i].title}
                        </a>
                    </li>
                `;
      }
    } else {
      if (i === 1) {
        navAnswer += `
                    <li>
                        <a class="nav-link scrollto" href=${initlist[i].href}>
                            ${initlist[i].title}
                        </a>
                    </li>
                `;
      } else if (i === 2) {
        navAnswer += `
                    <li>
                        <a class="nav-link scrollto" href=${initlist[i].href}>
                            ${initlist[i].title}
                        </a>
                    </li>
                `;
      }
    }
  }

  navContents.innerHTML = navAnswer;
}

function setPhotoLocal(local) {
  localStorage.setItem("photoLocal", local);
  localStorage.setItem("init", "true");
  window.location.replace("map.html");
}
