const getSavedUserInfos = () => {
  const userInfosJSON = localStorage.getItem("userInfos");
  try {
    return userInfosJSON ? JSON.parse(userInfosJSON) : [];
  } catch {
    return [];
  }
};

let userInfos = getSavedUserInfos();

function regist() {
  let id = document.getElementById("id").value;
  let password = document.getElementById("password").value;
  let name = document.getElementById("name").value;
  let email = document.getElementById("email").value;
  let age = document.getElementById("age").value;

  if (!id || !password || !name || !email || !age) {
    alert("빈칸이 없도록 입력해주세요.");
    return;
  } else {
    const user = JSON.parse(localStorage.getItem("userInfos"));
    let check = 0;

    if (user != null) {
      for (let i = 0; i < user.length; i++) {
        if (user[i].id === id) {
          alert("중복아이디 입니다!");
          check = 1;
          break;
        }
      }

      if (check === 0) {
        userInfos.push({
          id: id,
          password: password,
          username: name,
          email: email,
          age: age,
        });

        saveUserInfos(userInfos);

        alert("회원가입 성공!");
        window.location.replace("login.html");
      }
    } else {
      userInfos.push({
        id: id,
        password: password,
        username: name,
        email: email,
        age: age,
      });

      saveUserInfos(userInfos);

      alert("회원가입 성공!");
      window.location.replace("login.html");
    }
  }
}

const saveUserInfos = (userInfos) => {
  localStorage.setItem("userInfos", JSON.stringify(userInfos));
};

function login() {
  var flag = true;
  let id = document.getElementById("id").value;
  let password = document.getElementById("password").value;
  localStorage.removeItem("loginUser");

  const user = JSON.parse(localStorage.getItem("userInfos"));

  user.forEach((item) => {
    if (item.id === id && item.password === password) {
      console.log(item);
      localStorage.setItem("loginUser", JSON.stringify(item));
      alert("로그인 성공!");

      window.location.replace("index.html");
      flag = false;
      return false;
    }
  });

  if (flag) {
    alert("아이디 혹은 비밀번호가 일치하지 않습니다.");
    //return false;
  }
}

function logout() {
  localStorage.removeItem("loginUser");
  alert("로그아웃 성공!");
  window.location.replace("index.html");
}

function mypage() {
  const loginUser = JSON.parse(localStorage.getItem("loginUser"));
  let id = loginUser.id;
  let password = loginUser.password;
  let name = loginUser.username;
  let email = loginUser.email;
  let age = loginUser.age;

  document.getElementById("id").value = id;
  document.getElementById("password").value = password;
  document.getElementById("name").value = name;
  document.getElementById("email").value = email;
  document.getElementById("age").value = age;

  console.log(loginUser);
}

function edit() {
  var reads = document.getElementsByClassName("form-control");
  const flag = document.getElementById("readonlyFlag").value;
  if (flag === "true") {
    document.getElementById("readonlyFlag").value = "false";
    console.log(reads);
    for (var i = 1; i < reads.length; i++) {
      reads[i].readOnly = false;
    }
  } else {
    //수정
    const user = JSON.parse(localStorage.getItem("userInfos"));
    const loginUser = JSON.parse(localStorage.getItem("loginUser"));

    let idx = 0;

    let id = document.getElementById("id").value;
    let password = document.getElementById("password").value;
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let age = document.getElementById("age").value;
    user.forEach((item) => {
      if (item.id === loginUser.id) {
        console.log(item);

        user[idx].id = id;
        user[idx].password = password;
        user[idx].username = name;
        user[idx].email = email;
        user[idx].age = age;
        saveUserInfos(user);

        alert("회원정보 수정 성공!");
        return false;
      }
      idx++;
    });
    logout();
  }
}

function signout() {
  const user = JSON.parse(localStorage.getItem("userInfos"));
  const loginUser = JSON.parse(localStorage.getItem("loginUser"));
  let idx = 0;
  user.forEach((item) => {
    if (item.id === loginUser.id) {
      user.splice(idx, 1);
      localStorage.setItem("userInfos", JSON.stringify(user));
      localStorage.removeItem("loginUser");
      alert("회원탈퇴 성공!");

      window.location.replace("index.html");
    }
    idx++;
  });
}
