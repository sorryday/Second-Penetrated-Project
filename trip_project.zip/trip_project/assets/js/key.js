const serviceKey = " ";
export default serviceKey;
