var geocoder;

window.onload = function () {
  // 주소-좌표 변환 객체를 생성합니다
  geocoder = new kakao.maps.services.Geocoder();

  if (localStorage.getItem("contentId")) {
    map_select_picture();
    return;
  }

  if (localStorage.getItem("init") === "true") {
    map_main2(true);
    localStorage.setItem("init", false);
  } else {
    map_main();
  }
};

//======= START : 지도 생성 ==============================================================
//지도를 담을 영역의 DOM 레퍼런스
var mapContainer = document.getElementById("map");
var options = {
  //지도를 생성할 때 필요한 기본 옵션
  center: new kakao.maps.LatLng(37.54699, 127.09598), //지도의 중심좌표. 30개의 평균x , y
  level: 6, //지도의 레벨(작게보이게 설정하기 클수록 멀리보임)
};

var map = new kakao.maps.Map(mapContainer, options); //지도 생성 및 객체 리턴
//======= END : 지도 생성 ==============================================================

//★////// 주소명 검색하여 좌표 가져오기 //////////////

// var _loca1 = "대구"; // index.html에서 검색을 누를 때 받아올 시, 도 정보
// var _loac2 = "중구"; // index.html에서 검색을 누를 때 받아올 시 군 구? 정보
let _mapX_by_search;
let _mapY_by_search;
let temp;
// var searchAndGetXY = `${_loca1} ${_loac2}`;
var _boundary = 20000; // 검색 반경 (현재 사용하지 않음)

// 주소로 좌표를 검색하고 주변 정보를 불러옵니다.
function updateGlobalCoordinates(x, y, photo) {
  _mapX_by_search = x;
  _mapY_by_search = y;

  // ★ LOGIC //
  var _contentTypeId = localStorage.getItem("contents"); // index.html의 var 값으로 받아온다.

  console.log(_mapX_by_search, _mapY_by_search);
  var _mapX = _mapX_by_search; //  어디서 받아와야할 js에서 받아온다. _mapX_by_search
  var _mapY = _mapY_by_search; //  어디서 받아와야할 js에서 받아온다.
  const requestUrl = `https://apis.data.go.kr/B551011/KorService1/locationBasedList1?serviceKey=key%2FYBuoteqMEr27iWtQ%3D%3D&numOfRows=20&pageNo=1&MobileOS=ETC&MobileApp=AppTest&_type=json&listYN=Y&arrange=A&mapX=${_mapX}&mapY=${_mapY}&radius=15000&contentTypeId=${_contentTypeId}`;
  fetch(requestUrl)
    .then((response) => response.json())
    .then((data) => makeList(data, photo));
}

function map_main() {
  var searchAndGetXY = `${localStorage.getItem("local1")} ${localStorage.getItem("local2")}`;
  geocoder.addressSearch(searchAndGetXY, function (result, status) {
    // 정상적으로 검색이 완료됐으면
    if (status === kakao.maps.services.Status.OK) {
      let mapY = result[0].y;
      let mapX = result[0].x;

      updateGlobalCoordinates(mapX, mapY);

      console.log(_mapX_by_search, _mapY_by_search);
      // 결과값으로 받은 위치를 출력한다.
      // 128.606220516052 35.8693892533552
    }
  });
}

function map_main2(photo) {
  console.log(photo);
  var searchAndGetXY = `${localStorage.getItem("photoLocal")} ${""}`;
  geocoder.addressSearch(searchAndGetXY, function (result, status) {
    // 정상적으로 검색이 완료됐으면
    if (status === kakao.maps.services.Status.OK) {
      let mapY = result[0].y;
      let mapX = result[0].x;

      updateGlobalCoordinates(mapX, mapY, photo);

      console.log(_mapX_by_search, _mapY_by_search);
      // 결과값으로 받은 위치를 출력한다.
      // 128.606220516052 35.8693892533552
    }
  });
}
//★////// 주소명 검색하여 좌표 가져오기 END //////////
// ■■■■■■■■■■■■■
// 받아 온 값을 토대로 둘중 하나를 실행시키면 되지 않을까??
// map_main();
//map_select_picture();

// ■■■■■■■■■■■■■

///////////////// 사진을 누를 때 START (현재 쓰진 않음) /////////////////

function map_select_picture() {
  var _contentId = localStorage.getItem("contentId"); // 받아와야 하는 값!!!

  const picture_requestURL = `https://apis.data.go.kr/B551011/KorService1/detailCommon1?serviceKey=key%2FYBuoteqMEr27iWtQ%3D%3D&MobileOS=ETC&MobileApp=AppTest&_type=json&contentId=${_contentId}&defaultYN=Y&addrinfoYN=Y&mapinfoYN=Y&overviewYN=Y&numOfRows=10&pageNo=1&firstImageYN=Y`;
  fetch(picture_requestURL)
    .then((response) => response.json())
    .then((data) => makeList(data));

  function closeOverlay() {
    overlay_sel.setMap(null);
  }
}
/////////////////////// 사진을 누를 때 END ////////////////////////

function displayMarker() {
  // 마커 이미지의 이미지 주소입니다
  var imageSrc = "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/markerStar.png";
  console.log(positions.length);
  for (var i = 0; i < positions.length; i++) {
    // 마커 이미지의 이미지 크기 입니다
    var imageSize = new kakao.maps.Size(24, 35);

    // 마커 이미지를 생성합니다
    var markerImage = new kakao.maps.MarkerImage(imageSrc, imageSize);

    // 마커를 생성합니다
    var marker = new kakao.maps.Marker({
      map: map, // 마커를 표시할 지도
      position: positions[i].latlng, // 마커를 표시할 위치
      title: positions[i].title, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
      content: positions[i].content,
      image: markerImage, // 마커 이미지
    });

    //커스텀 오버레이를 만들어 줬음!!
    kakao.maps.event.addListener(
      marker,
      "click",
      makeClickListener(map, marker, positions[i].content)
    );
  }

  map.setCenter(positions[0].latlng);
}

var customOverlay;

function makeClickListener(map, marker, content) {
  return function () {
    if (customOverlay) {
      customOverlay.setMap(null);
    }
    customOverlay = new kakao.maps.CustomOverlay({
      map: map,
      position: marker.getPosition(),
      content: content,
      xAnchor: 0.3,
      yAnchor: 0.91,
    });
    customOverlay.setMap(map);
    // var options = {
    //   //지도를 생성할 때 필요한 기본 옵션
    //   center: new kakao.maps.LatLng(37.54699, 127.09598), //지도의 중심좌표. 30개의 평균x , y
    //   level: 6, //지도의 레벨(작게보이게 설정하기 클수록 멀리보임)
    // };
    map.setCenter(marker.getPosition());
  };
}

//==== START : 오버레이 닫기 위해 만든 함수
function closeOverlay() {
  if (customOverlay) {
    customOverlay.setMap(null);
    customOverlay = null;
  }
}

function makeList(data, photo) {
  let trips = data.response.body.items.item;

  if (photo) {
    localStorage.setItem("trips", JSON.stringify(trips));
    window.location.replace("index.html");
  }

  console.log(trips);
  console.log(trips.length);
  let tripList = ``;
  positions = [];
  trips.forEach((area) => {
    tripList += `
                <tr onclick="moveCenter(${area.mapy}, ${area.mapx});">
                  <td><img src="${area.firstimage}" width="100px"></td>
                  <td>${area.title}</td>
                  <td>${area.addr1} ${area.addr2}</td>
                  <td>${area.mapy}</td>
                  <td>${area.mapx}</td>
                </tr>
              `;
    content = ` <div class="wrap">
                    <div class="info">
                        <div class="title">
                            ${area.title}
                            <div class="close" onclick="closeOverlay()" title="닫기"></div>
                        </div>
                        <div class="body">
                          s  <div class="img">
                                <img src="${area.firstimage}" width="73" height="70">'
                           </div>'
                            <div class="desc">
                                <div class="ellipsis">${area.addr1}</div>
                                <div class="jibun ellipsis">${area.addr2}</div>
                                <div><a href="https://www.kakaocorp.com/main" target="_blank" class="link">홈페이지</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                `;
    let markerInfo = {
      title: area.title,
      latlng: new kakao.maps.LatLng(area.mapy, area.mapx),
      content: content,
    };
    positions.push(markerInfo);
  });

  document.getElementById("trip-list").innerHTML = tripList; // 리스트 출력과 관련된 것 ★
  displayMarker();
}

function moveCenter(lat, lng) {
  map.setCenter(new kakao.maps.LatLng(lat, lng));
}
