const getSavedPostLists = () => {
  const postListJson = localStorage.getItem("postList");
  try {
    return postListJson ? JSON.parse(postListJson) : [];
  } catch {
    return [];
  }
};
let postList = getSavedPostLists();

function post() {
  let title = document.querySelector("#postTitle").value;
  let content = document.querySelector("#postContent").value;
  let loginUser = JSON.parse(localStorage.getItem("loginUser"));

  if (loginUser === null) {
    alert("로그인 필수!");
  } else {
    postList.push({
      title: title,
      username: loginUser.username,
      content: content,
      date: new Date(),
    });

    savePostList(postList);

    alert("게시판 등록 성공!");

    window.location.replace("board.html");
  }
}

const savePostList = (postList) => {
  localStorage.setItem("postList", JSON.stringify(postList));
};

function boardDetailGo(idx) {
  const item = JSON.parse(localStorage.getItem("postList"));
  console.log(item[idx - 1]);
  localStorage.setItem("postDetail", JSON.stringify(item[idx - 1]));
  localStorage.setItem("postIdx", idx - 1);
  window.location.replace("boardDetail.html");
}

function editPost() {
  const idx = localStorage.getItem("postIdx");
  const postList = JSON.parse(localStorage.getItem("postList"));

  postList[idx].title = document.querySelector("#postTitle").value;
  postList[idx].content = document.querySelector("#postContent").value;
  savePostList(postList);

  alert("게시물 수정 성공!");

  window.location.replace("board.html");
}

function deletePost() {
  const idx = localStorage.getItem("postIdx");
  const postList = JSON.parse(localStorage.getItem("postList"));

  postList.splice(idx, 1);

  localStorage.setItem("postList", JSON.stringify(postList));

  alert("게시물 삭제 성공!");
  window.location.replace("board.html");
}
